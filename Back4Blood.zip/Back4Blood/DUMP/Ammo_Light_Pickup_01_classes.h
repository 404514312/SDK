// BlueprintGeneratedClass Ammo_Light_Pickup_01.Ammo_Light_Pickup_01_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Light_Pickup_01_C : AAmmo_Light_Pickup_Single_BP_C {
};

