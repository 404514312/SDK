// BlueprintGeneratedClass AISpawnActor_Sleeper_Wall_BP.AISpawnActor_Sleeper_Wall_BP_C
// Size: 0x578 (Inherited: 0x570)
struct AAISpawnActor_Sleeper_Wall_BP_C : AAISpawnActor_BP_C {
	struct UHeroLOSVolumeComponent* HeroLOSVolume; // 0x570(0x08)
};

