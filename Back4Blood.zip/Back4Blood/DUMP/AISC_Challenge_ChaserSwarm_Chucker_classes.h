// BlueprintGeneratedClass AISC_Challenge_ChaserSwarm_Chucker.AISC_Challenge_ChaserSwarm_Chucker_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Challenge_ChaserSwarm_Chucker_C : UAISC_Horde_ChaserBasic_C {
};

