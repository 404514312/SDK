// BlueprintGeneratedClass Ability_Hunker_Mod.Ability_Hunker_Mod_C
// Size: 0x230 (Inherited: 0x230)
struct UAbility_Hunker_Mod_C : UApplyOnTagMod {
};

