// BlueprintGeneratedClass AISC_Horde_CamoArmored_Jog.AISC_Horde_CamoArmored_Jog_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_CamoArmored_Jog_C : UAISC_Horde_Armored_Jog_C {
};

