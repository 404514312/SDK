// BlueprintGeneratedClass AISC_PvP_Mutation_Common_AddSleepers.AISC_PvP_Mutation_Common_AddSleepers_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_PvP_Mutation_Common_AddSleepers_C : UAISC_WanderBase_C {
};

