// BlueprintGeneratedClass Achievement_GrabBag_028.Achievement_GrabBag_028_C
// Size: 0xc0 (Inherited: 0xc0)
struct UAchievement_GrabBag_028_C : UAchievement {
};

