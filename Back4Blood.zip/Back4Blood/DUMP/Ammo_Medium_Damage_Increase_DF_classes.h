// BlueprintGeneratedClass Ammo_Medium_Damage_Increase_DF.Ammo_Medium_Damage_Increase_DF_C
// Size: 0x40 (Inherited: 0x40)
struct UAmmo_Medium_Damage_Increase_DF_C : UDamageFilter {
};

