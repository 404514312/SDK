// BlueprintGeneratedClass Ability_ChargedMelee_Mod.Ability_ChargedMelee_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAbility_ChargedMelee_Mod_C : UApplyGameplayEffectMod {
};

