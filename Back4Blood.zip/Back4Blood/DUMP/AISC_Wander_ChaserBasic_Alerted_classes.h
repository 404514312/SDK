// BlueprintGeneratedClass AISC_Wander_ChaserBasic_Alerted.AISC_Wander_ChaserBasic_Alerted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_ChaserBasic_Alerted_C : UAISC_WanderBase_C {
};

