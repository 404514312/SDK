// BlueprintGeneratedClass AISC_Horde_ChaserChucker.AISC_Horde_ChaserChucker_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_ChaserChucker_C : UAISC_Horde_ChaserBasic_C {
};

