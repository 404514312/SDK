// BlueprintGeneratedClass AISmartActor_BP.AISmartActor_BP_C
// Size: 0x478 (Inherited: 0x460)
struct AAISmartActor_BP_C : AAISmartActor {
	struct USphereComponent* Sphere; // 0x460(0x08)
	struct UArrowComponent* Arrow; // 0x468(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x470(0x08)
};

