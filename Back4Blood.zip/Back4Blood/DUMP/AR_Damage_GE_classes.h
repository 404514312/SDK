// BlueprintGeneratedClass AR_Damage_GE.AR_Damage_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAR_Damage_GE_C : UGameplayEffectDamageFilter {
};

