// BlueprintGeneratedClass Ammo_Secondary_Pickup_01.Ammo_Secondary_Pickup_01_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Secondary_Pickup_01_C : AAmmo_Secondary_Pickup_Single_BP_C {
};

