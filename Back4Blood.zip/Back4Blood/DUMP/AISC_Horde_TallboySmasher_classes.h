// BlueprintGeneratedClass AISC_Horde_TallboySmasher.AISC_Horde_TallboySmasher_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_TallboySmasher_C : UAISC_Horde_TallboyBasic_C {
};

