// UserDefinedStruct AR_Tuning_Struct.AR_Tuning_Struct
// Size: 0x2b8 (Inherited: 0x00)
struct FAR_Tuning_Struct {
	struct FFireModeBaseTuning FireModeBase_44_68220EBE4CFC59F056648DA4C9A6CFDB; // 0x00(0x34)
	char pad_34[0x4]; // 0x34(0x04)
	struct FFireModeSingleTraceTuning FireModeSingleTrace_38_A8269C094B5739F9F33E60A3D0CD4081; // 0x38(0x18)
	struct FSpreadTuning Spread_15_F415F8754C89D8B245443DA492E3C17B; // 0x50(0x60)
	struct FClipAmmoTuning ClipAmmo_34_58756FF64ADE64096DBB01BEDEABAEB3; // 0xb0(0x04)
	struct FClipReloadTuning ClipReload_3_FD477EAF4A650B258356838D708AAE34; // 0xb4(0x0c)
	struct FRecoilTuning Recoil_18_165730B741DF2E5C4ED7AA9DDCAF93E4; // 0xc0(0x140)
	struct FBulletPenetrationTuning BulletPenetration_31_1F925B5145A1D0C32BC863A7AC9319E2; // 0x200(0x04)
	struct FWeaponMoveSpeedTuning WeaponMoveSpeed_21_213B84A543E5E1C4DF48BBBFA5DA2289; // 0x204(0x6c)
	struct FItemCycleTuning ItemCycle_27_DF9809044F21D22D184C019CA8F9E505; // 0x270(0x14)
	struct FADSTuning ADS_41_68B93C784348D505292F21AF9493E76C; // 0x284(0x08)
	struct FItemAnimationDataTuning ItemAnimationData_28_8362ACD143435AF565B9C2BB0C148327; // 0x28c(0x2c)
};

