// BlueprintGeneratedClass Ability_Reflected_Bandages_Mod.Ability_Reflected_Bandages_Mod_C
// Size: 0x228 (Inherited: 0x228)
struct UAbility_Reflected_Bandages_Mod_C : UApplyOnItemAppliedMod {
};

