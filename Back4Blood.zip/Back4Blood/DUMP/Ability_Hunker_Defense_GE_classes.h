// BlueprintGeneratedClass Ability_Hunker_Defense_GE.Ability_Hunker_Defense_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAbility_Hunker_Defense_GE_C : UGameplayEffectDamageFilter {
};

