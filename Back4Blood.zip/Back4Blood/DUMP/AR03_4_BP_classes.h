// BlueprintGeneratedClass AR03_4_BP.AR03_4_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR03_4_BP_C : AAR03_BP_C {
};

