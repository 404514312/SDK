// BlueprintGeneratedClass AISC_Wander_TallboySqueezer.AISC_Wander_TallboySqueezer_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_TallboySqueezer_C : UAISC_WanderBase_C {
};

