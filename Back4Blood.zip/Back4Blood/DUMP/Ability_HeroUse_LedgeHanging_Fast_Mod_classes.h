// BlueprintGeneratedClass Ability_HeroUse_LedgeHanging_Fast_Mod.Ability_HeroUse_LedgeHanging_Fast_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAbility_HeroUse_LedgeHanging_Fast_Mod_C : UApplyGameplayEffectMod {
};

