// BlueprintGeneratedClass AR03_2_BP.AR03_2_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR03_2_BP_C : AAR03_BP_C {
};

