// BlueprintGeneratedClass AcidPool_CameraModifier.AcidPool_CameraModifier_C
// Size: 0x630 (Inherited: 0x630)
struct UAcidPool_CameraModifier_C : UCameraModifier_ScreenEffect {
};

