// BlueprintGeneratedClass AR05_4_BP.AR05_4_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR05_4_BP_C : AAR05_BP_C {
};

