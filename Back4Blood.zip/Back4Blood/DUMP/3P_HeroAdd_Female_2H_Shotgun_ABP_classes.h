// AnimBlueprintGeneratedClass 3P_HeroAdd_Female_2H_Shotgun_ABP.3P_HeroAdd_Female_2H_Shotgun_ABP_C
// Size: 0x2487 (Inherited: 0x2487)
struct U3P_HeroAdd_Female_2H_Shotgun_ABP_C : U3P_HeroAdd_2H_Shotgun_ABP_C {
};

