// BlueprintGeneratedClass AISpawnActor_BaseNPC_FullHero_BP.AISpawnActor_BaseNPC_FullHero_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AAISpawnActor_BaseNPC_FullHero_BP_C : AAISpawnActor_BP_C {
};

