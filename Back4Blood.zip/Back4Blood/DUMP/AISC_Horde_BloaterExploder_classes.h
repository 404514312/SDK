// BlueprintGeneratedClass AISC_Horde_BloaterExploder.AISC_Horde_BloaterExploder_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_BloaterExploder_C : UAISC_Horde_BloaterVomiter_C {
};

