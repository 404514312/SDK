// BlueprintGeneratedClass AR02_3_BP.AR02_3_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR02_3_BP_C : AAR02_BP_C {
};

