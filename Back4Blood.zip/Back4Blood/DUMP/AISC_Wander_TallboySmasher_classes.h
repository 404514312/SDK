// BlueprintGeneratedClass AISC_Wander_TallboySmasher.AISC_Wander_TallboySmasher_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_TallboySmasher_C : UAISC_WanderBase_C {
};

