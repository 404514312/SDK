// BlueprintGeneratedClass Ability_ChargedMelee_Tag_GE.Ability_ChargedMelee_Tag_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAbility_ChargedMelee_Tag_GE_C : UGameplayEffectSetTags {
};

