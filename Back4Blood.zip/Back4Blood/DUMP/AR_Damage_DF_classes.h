// BlueprintGeneratedClass AR_Damage_DF.AR_Damage_DF_C
// Size: 0x40 (Inherited: 0x40)
struct UAR_Damage_DF_C : UDamageFilter {
};

