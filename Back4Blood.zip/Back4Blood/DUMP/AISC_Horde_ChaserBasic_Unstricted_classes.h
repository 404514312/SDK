// BlueprintGeneratedClass AISC_Horde_ChaserBasic_Unstricted.AISC_Horde_ChaserBasic_Unstricted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_ChaserBasic_Unstricted_C : UAISC_HordingBase_C {
};

