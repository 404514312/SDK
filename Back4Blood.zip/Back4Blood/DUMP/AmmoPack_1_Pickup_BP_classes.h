// BlueprintGeneratedClass AmmoPack_1_Pickup_BP.AmmoPack_1_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAmmoPack_1_Pickup_BP_C : AItemPickupBase_BP_C {
};

