// BlueprintGeneratedClass Ability_BackgroundReload_Mod.Ability_BackgroundReload_Mod_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAbility_BackgroundReload_Mod_C : UApplyTagMod {
};

