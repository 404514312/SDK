// BlueprintGeneratedClass AISpawnActor_Open_AvgBig_BP.AISpawnActor_Open_AvgBig_BP_C
// Size: 0x578 (Inherited: 0x570)
struct AAISpawnActor_Open_AvgBig_BP_C : AAISpawnActor_Open_BP_C {
	struct UHeroLOSVolumeComponent* HeroLOSVolume; // 0x570(0x08)
};

