// BlueprintGeneratedClass Ammo_Secondary_Pickup_LargeB_BP.Ammo_Secondary_Pickup_LargeB_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Secondary_Pickup_LargeB_BP_C : AAmmo_Pickup_Base_BP_C {
};

