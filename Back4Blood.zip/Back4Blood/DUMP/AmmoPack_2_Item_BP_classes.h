// BlueprintGeneratedClass AmmoPack_2_Item_BP.AmmoPack_2_Item_BP_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct AAmmoPack_2_Item_BP_C : AAmmoPack_1_Item_BP_C {
};

