// BlueprintGeneratedClass AISC_Brute.AISC_Brute_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Brute_C : UAISC_HordingBase_C {
};

