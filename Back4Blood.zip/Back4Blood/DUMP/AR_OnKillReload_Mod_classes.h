// BlueprintGeneratedClass AR_OnKillReload_Mod.AR_OnKillReload_Mod_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct UAR_OnKillReload_Mod_C : UApplyDamageDealtEffectsMod {
};

