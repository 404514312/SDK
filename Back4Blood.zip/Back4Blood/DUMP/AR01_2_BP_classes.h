// BlueprintGeneratedClass AR01_2_BP.AR01_2_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR01_2_BP_C : AAR01_BP_C {
};

