// BlueprintGeneratedClass Achievement_NonPlatform_049.Achievement_NonPlatform_049_C
// Size: 0xc0 (Inherited: 0xc0)
struct UAchievement_NonPlatform_049_C : UAchievement {
};

