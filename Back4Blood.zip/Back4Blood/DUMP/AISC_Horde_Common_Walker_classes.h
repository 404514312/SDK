// BlueprintGeneratedClass AISC_Horde_Common_Walker.AISC_Horde_Common_Walker_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_Common_Walker_C : UAISC_HordingBase_C {
};

