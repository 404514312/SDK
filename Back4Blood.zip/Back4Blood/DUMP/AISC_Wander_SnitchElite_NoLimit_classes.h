// BlueprintGeneratedClass AISC_Wander_SnitchElite_NoLimit.AISC_Wander_SnitchElite_NoLimit_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_SnitchElite_NoLimit_C : UAISC_WanderBase_C {
};

