// BlueprintGeneratedClass AR04_4_Pickup_BP.AR04_4_Pickup_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAR04_4_Pickup_BP_C : AAR04_1_Pickup_BP_C {
};

