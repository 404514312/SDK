// BlueprintGeneratedClass AR05_BP.AR05_BP_C
// Size: 0x558 (Inherited: 0x518)
struct AAR05_BP_C : ABaseGun_Static_BP_C {
	struct UADSComponent* ADS; // 0x518(0x08)
	struct UFireModeSingleTraceComponent* FireModeSingleTrace; // 0x520(0x08)
	struct UBulletPenetrationComponent* BulletPenetration; // 0x528(0x08)
	struct UClipAmmoComponent* ClipAmmo; // 0x530(0x08)
	struct URecoilComponent* Recoil; // 0x538(0x08)
	struct UClipReloadComponent* ClipReload; // 0x540(0x08)
	struct USpreadComponent* Spread; // 0x548(0x08)
	struct UItemAnimationDataComponent* ItemAnimationData; // 0x550(0x08)
};

