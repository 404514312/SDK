// BlueprintGeneratedClass AISpawnActor_BP.AISpawnActor_BP_C
// Size: 0x570 (Inherited: 0x550)
struct AAISpawnActor_BP_C : ACharacterSpawnActor {
	struct USceneComponent* Scene; // 0x550(0x08)
	struct UBillboardComponent* Billboard; // 0x558(0x08)
	struct UArrowComponent* Arrow; // 0x560(0x08)
	struct UNavLocationComponent* NavLocation; // 0x568(0x08)
};

