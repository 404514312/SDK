// BlueprintGeneratedClass Ammo_Secondary_Pickup_03.Ammo_Secondary_Pickup_03_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Secondary_Pickup_03_C : AAmmo_Secondary_Pickup_Single_BP_C {
};

