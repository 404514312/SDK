// BlueprintGeneratedClass AR06_4_BP.AR06_4_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR06_4_BP_C : AAR06_BP_C {
};

