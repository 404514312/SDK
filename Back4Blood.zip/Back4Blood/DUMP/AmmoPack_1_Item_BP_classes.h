// BlueprintGeneratedClass AmmoPack_1_Item_BP.AmmoPack_1_Item_BP_C
// Size: 0x4c8 (Inherited: 0x4b0)
struct AAmmoPack_1_Item_BP_C : ABaseUtility_BP_C {
	struct UFPRigSkeletalMeshComponent* BaseSkeletalMesh_1P; // 0x4b0(0x08)
	struct UClipAmmoComponent* ClipAmmo; // 0x4b8(0x08)
	struct UAmmoPouchComponent* AmmoPouch; // 0x4c0(0x08)
};

