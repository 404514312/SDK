// BlueprintGeneratedClass AnimContext_AvatarFacingClingLocation.AnimContext_AvatarFacingClingLocation_C
// Size: 0x70 (Inherited: 0x70)
struct UAnimContext_AvatarFacingClingLocation_C : UAnimContext_Facing {
};

