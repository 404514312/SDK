// BlueprintGeneratedClass Alerted_Cooldown_GE.Alerted_Cooldown_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAlerted_Cooldown_GE_C : UGameplayEffectSetTags {
};

