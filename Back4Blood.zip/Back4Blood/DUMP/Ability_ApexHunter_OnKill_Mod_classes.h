// BlueprintGeneratedClass Ability_ApexHunter_OnKill_Mod.Ability_ApexHunter_OnKill_Mod_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct UAbility_ApexHunter_OnKill_Mod_C : UApplyDamageDealtEffectsMod {
};

