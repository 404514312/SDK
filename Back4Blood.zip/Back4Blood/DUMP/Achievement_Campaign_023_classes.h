// BlueprintGeneratedClass Achievement_Campaign_023.Achievement_Campaign_023_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAchievement_Campaign_023_C : UMissionsCompletedAchievement {
};

