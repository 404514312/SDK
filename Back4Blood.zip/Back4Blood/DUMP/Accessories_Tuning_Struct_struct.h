// UserDefinedStruct Accessories_Tuning_Struct.Accessories_Tuning_Struct
// Size: 0xb0 (Inherited: 0x00)
struct FAccessories_Tuning_Struct {
	struct FClipAmmoTuning ClipAmmo_34_58756FF64ADE64096DBB01BEDEABAEB3; // 0x00(0x04)
	struct FWeaponMoveSpeedTuning WeaponMoveSpeed_21_213B84A543E5E1C4DF48BBBFA5DA2289; // 0x04(0x6c)
	struct FItemCycleTuning ItemCycle_27_DF9809044F21D22D184C019CA8F9E505; // 0x70(0x14)
	struct FItemAnimationDataTuning ItemAnimationData_28_8362ACD143435AF565B9C2BB0C148327; // 0x84(0x2c)
};

