// BlueprintGeneratedClass Alarm_Door_High_Mod.Alarm_Door_High_Mod_C
// Size: 0x288 (Inherited: 0x288)
struct UAlarm_Door_High_Mod_C : UPassageSpawnerMod {
};

