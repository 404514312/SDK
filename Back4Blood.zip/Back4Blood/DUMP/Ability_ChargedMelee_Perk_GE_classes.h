// BlueprintGeneratedClass Ability_ChargedMelee_Perk_GE.Ability_ChargedMelee_Perk_GE_C
// Size: 0x250 (Inherited: 0x250)
struct UAbility_ChargedMelee_Perk_GE_C : UGameplayEffectApplyPerk {
};

