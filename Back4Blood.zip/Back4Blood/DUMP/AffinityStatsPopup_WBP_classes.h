// WidgetBlueprintGeneratedClass AffinityStatsPopup_WBP.AffinityStatsPopup_WBP_C
// Size: 0x4a0 (Inherited: 0x480)
struct UAffinityStatsPopup_WBP_C : UAffinityStatsPopup {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct UBaseTextBlock_C* Desc; // 0x488(0x08)
	struct UButton* InvisibleFocusTarget; // 0x490(0x08)
	struct UBaseTextBlock_C* Title; // 0x498(0x08)

	void InitInput(); // Function AffinityStatsPopup_WBP.AffinityStatsPopup_WBP_C.InitInput // (BlueprintCallable|BlueprintEvent) // @ game+0x2552680
};

