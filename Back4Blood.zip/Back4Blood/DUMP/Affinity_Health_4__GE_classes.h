// BlueprintGeneratedClass Affinity_Health_4__GE.Affinity_Health_4__GE_C
// Size: 0x318 (Inherited: 0x318)
struct UAffinity_Health_4__GE_C : UGameplayEffectHealthComponent {
};

