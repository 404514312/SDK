// BlueprintGeneratedClass AISC_Horde_TallboyBasic_Unrestricted.AISC_Horde_TallboyBasic_Unrestricted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_TallboyBasic_Unrestricted_C : UAISC_HordingBase_C {
};

