// BlueprintGeneratedClass AcidPool_ScreenEffect.AcidPool_ScreenEffect_C
// Size: 0x98 (Inherited: 0x98)
struct UAcidPool_ScreenEffect_C : UScreenEffect {
};

