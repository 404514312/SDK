// BlueprintGeneratedClass AISC_Challenge_SwarmTallboy_Basic.AISC_Challenge_SwarmTallboy_Basic_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Challenge_SwarmTallboy_Basic_C : UAISC_Horde_TallboyBasic_C {
};

