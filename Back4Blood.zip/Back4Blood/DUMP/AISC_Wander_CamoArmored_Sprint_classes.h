// BlueprintGeneratedClass AISC_Wander_CamoArmored_Sprint.AISC_Wander_CamoArmored_Sprint_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_CamoArmored_Sprint_C : UAISC_WanderBase_C {
};

