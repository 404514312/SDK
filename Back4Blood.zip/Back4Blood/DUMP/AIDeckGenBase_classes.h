// BlueprintGeneratedClass AIDeckGenBase.AIDeckGenBase_C
// Size: 0x1a8 (Inherited: 0x78)
struct UAIDeckGenBase_C : UAISpawnConditionEvaluatorSet {
	struct FAISpawnEval_Chance Chance; // 0x78(0x58)
	struct FAISpawnEval_CheckGeneratingDeckTags Check Generating Deck Tags; // 0xd0(0x90)
	struct FAISpawnEval_Difficulty Difficulty; // 0x160(0x48)
};

