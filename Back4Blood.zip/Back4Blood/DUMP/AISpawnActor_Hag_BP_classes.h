// BlueprintGeneratedClass AISpawnActor_Hag_BP.AISpawnActor_Hag_BP_C
// Size: 0x578 (Inherited: 0x570)
struct AAISpawnActor_Hag_BP_C : AAISpawnActor_BP_C {
	struct UTextRenderComponent* TextRender; // 0x570(0x08)
};

