// BlueprintGeneratedClass Ammo_Heavy_Pickup_04.Ammo_Heavy_Pickup_04_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Heavy_Pickup_04_C : AAmmo_Heavy_Pickup_Single_BP_C {
};

