// BlueprintGeneratedClass AR01_4_Pickup_BP.AR01_4_Pickup_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAR01_4_Pickup_BP_C : AAR01_1_Pickup_BP_C {
};

