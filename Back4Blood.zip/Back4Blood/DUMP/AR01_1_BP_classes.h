// BlueprintGeneratedClass AR01_1_BP.AR01_1_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR01_1_BP_C : AAR01_BP_C {
};

