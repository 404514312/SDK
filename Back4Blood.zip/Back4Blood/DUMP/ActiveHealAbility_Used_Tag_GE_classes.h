// BlueprintGeneratedClass ActiveHealAbility_Used_Tag_GE.ActiveHealAbility_Used_Tag_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UActiveHealAbility_Used_Tag_GE_C : UGameplayEffectSetTags {
};

