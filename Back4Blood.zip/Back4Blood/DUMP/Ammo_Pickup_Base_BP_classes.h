// BlueprintGeneratedClass Ammo_Pickup_Base_BP.Ammo_Pickup_Base_BP_C
// Size: 0x548 (Inherited: 0x540)
struct AAmmo_Pickup_Base_BP_C : AItemPickupBase_BP_C {
	struct UMaterialBillboardComponent* MaterialBillboard; // 0x540(0x08)
};

