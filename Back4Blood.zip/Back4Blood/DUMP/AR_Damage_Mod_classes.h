// BlueprintGeneratedClass AR_Damage_Mod.AR_Damage_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAR_Damage_Mod_C : UApplyGameplayEffectMod {
};

