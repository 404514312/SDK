// BlueprintGeneratedClass AISC_Horde_TallboySqueezer.AISC_Horde_TallboySqueezer_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_TallboySqueezer_C : UAISC_Horde_TallboyBasic_C {
};

