// BlueprintGeneratedClass AISpawnActor_Open_Huge_BP.AISpawnActor_Open_Huge_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AAISpawnActor_Open_Huge_BP_C : AAISpawnActor_BP_C {
};

