// BlueprintGeneratedClass AISpawnActor_SpawnCloset_BP.AISpawnActor_SpawnCloset_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AAISpawnActor_SpawnCloset_BP_C : AAISpawnActor_BP_C {
};

