// Class AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary
// Size: 0x30 (Inherited: 0x30)
struct UAnalyticsBlueprintLibrary : UBlueprintFunctionLibrary {

	bool StartSessionWithAttributes(struct TArray<struct FAnalyticsEventAttr>& Attributes); // Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xf4fad0
};

