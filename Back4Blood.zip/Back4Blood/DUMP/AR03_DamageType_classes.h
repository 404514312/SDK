// BlueprintGeneratedClass AR03_DamageType.AR03_DamageType_C
// Size: 0x60 (Inherited: 0x60)
struct UAR03_DamageType_C : UBullet_DamageType_C {
};

