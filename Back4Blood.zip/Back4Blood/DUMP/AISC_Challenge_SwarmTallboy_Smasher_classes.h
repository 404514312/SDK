// BlueprintGeneratedClass AISC_Challenge_SwarmTallboy_Smasher.AISC_Challenge_SwarmTallboy_Smasher_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Challenge_SwarmTallboy_Smasher_C : UAISC_Horde_TallboyBasic_C {
};

