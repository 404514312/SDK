// BlueprintGeneratedClass AmmoPack_3_Item_BP.AmmoPack_3_Item_BP_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct AAmmoPack_3_Item_BP_C : AAmmoPack_1_Item_BP_C {
};

