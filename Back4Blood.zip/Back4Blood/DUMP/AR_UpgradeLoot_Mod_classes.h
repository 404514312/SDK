// BlueprintGeneratedClass AR_UpgradeLoot_Mod.AR_UpgradeLoot_Mod_C
// Size: 0x108 (Inherited: 0x108)
struct UAR_UpgradeLoot_Mod_C : ULootUpgradeMod {
};

