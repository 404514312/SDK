// BlueprintGeneratedClass AISC_ChallengeBrute.AISC_ChallengeBrute_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_ChallengeBrute_C : UAISC_HordingBase_C {
};

