// BlueprintGeneratedClass AR03_2_Pickup_BP.AR03_2_Pickup_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAR03_2_Pickup_BP_C : AAR03_1_Pickup_BP_C {
};

