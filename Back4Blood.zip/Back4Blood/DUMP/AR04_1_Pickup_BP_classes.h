// BlueprintGeneratedClass AR04_1_Pickup_BP.AR04_1_Pickup_BP_C
// Size: 0x548 (Inherited: 0x540)
struct AAR04_1_Pickup_BP_C : AItemPickupBase_BP_C {
	struct UStaticMeshComponent* SightMesh; // 0x540(0x08)
};

