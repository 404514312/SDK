// BlueprintGeneratedClass ADSBlur2_ScreenEffect.ADSBlur2_ScreenEffect_C
// Size: 0x98 (Inherited: 0x98)
struct UADSBlur2_ScreenEffect_C : UScreenEffect {
};

