// BlueprintGeneratedClass Ammo_Light_Pickup_Large_BP.Ammo_Light_Pickup_Large_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Light_Pickup_Large_BP_C : AAmmo_Pickup_Base_BP_C {
};

