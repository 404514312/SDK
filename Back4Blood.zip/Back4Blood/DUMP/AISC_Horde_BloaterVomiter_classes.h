// BlueprintGeneratedClass AISC_Horde_BloaterVomiter.AISC_Horde_BloaterVomiter_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_BloaterVomiter_C : UAISC_Horde_BloaterBasic_C {
};

