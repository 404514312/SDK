// BlueprintGeneratedClass Ammo_Heavy_Pickup_01.Ammo_Heavy_Pickup_01_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Heavy_Pickup_01_C : AAmmo_Heavy_Pickup_Single_BP_C {
};

