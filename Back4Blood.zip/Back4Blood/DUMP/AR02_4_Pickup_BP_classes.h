// BlueprintGeneratedClass AR02_4_Pickup_BP.AR02_4_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAR02_4_Pickup_BP_C : AAR02_1_Pickup_BP_C {
};

