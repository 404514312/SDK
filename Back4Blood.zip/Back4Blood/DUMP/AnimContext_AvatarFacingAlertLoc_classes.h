// BlueprintGeneratedClass AnimContext_AvatarFacingAlertLoc.AnimContext_AvatarFacingAlertLoc_C
// Size: 0x70 (Inherited: 0x70)
struct UAnimContext_AvatarFacingAlertLoc_C : UAnimContext_Facing {
};

