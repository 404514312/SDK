// BlueprintGeneratedClass AR02_DamageType.AR02_DamageType_C
// Size: 0x60 (Inherited: 0x60)
struct UAR02_DamageType_C : UBullet_DamageType_C {
};

