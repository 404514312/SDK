// BlueprintGeneratedClass Achievement_Campaign_018.Achievement_Campaign_018_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAchievement_Campaign_018_C : UMissionsCompletedAchievement {
};

