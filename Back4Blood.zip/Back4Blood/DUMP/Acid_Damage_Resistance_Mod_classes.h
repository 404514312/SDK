// BlueprintGeneratedClass Acid_Damage_Resistance_Mod.Acid_Damage_Resistance_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAcid_Damage_Resistance_Mod_C : UApplyGameplayEffectMod {
};

