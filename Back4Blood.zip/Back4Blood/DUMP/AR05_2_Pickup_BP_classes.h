// BlueprintGeneratedClass AR05_2_Pickup_BP.AR05_2_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAR05_2_Pickup_BP_C : AAR05_1_Pickup_BP_C {
};

