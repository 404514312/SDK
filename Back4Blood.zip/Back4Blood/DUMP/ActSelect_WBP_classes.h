// WidgetBlueprintGeneratedClass ActSelect_WBP.ActSelect_WBP_C
// Size: 0x4b0 (Inherited: 0x4a0)
struct UActSelect_WBP_C : UActSelectUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UVerticalBox* ActPanel; // 0x4a8(0x08)

	void PreConstruct(bool IsDesignTime); // Function ActSelect_WBP.ActSelect_WBP_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2552680
};

