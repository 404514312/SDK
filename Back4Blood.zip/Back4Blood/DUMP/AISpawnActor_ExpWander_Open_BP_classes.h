// BlueprintGeneratedClass AISpawnActor_ExpWander_Open_BP.AISpawnActor_ExpWander_Open_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AAISpawnActor_ExpWander_Open_BP_C : AAISpawnActor_Open_BP_C {
};

