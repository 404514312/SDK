// BlueprintGeneratedClass AR_Penetration_GE.AR_Penetration_GE_C
// Size: 0x258 (Inherited: 0x258)
struct UAR_Penetration_GE_C : UGameplayEffectBulletPenetrationComponent {
};

