// BlueprintGeneratedClass AISC_WanderBase.AISC_WanderBase_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_WanderBase_C : UAISpawnCard {
};

