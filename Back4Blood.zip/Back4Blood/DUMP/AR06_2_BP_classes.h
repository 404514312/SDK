// BlueprintGeneratedClass AR06_2_BP.AR06_2_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR06_2_BP_C : AAR06_BP_C {
};

