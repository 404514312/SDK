// BlueprintGeneratedClass AmmoFinder_Melee_Mod.AmmoFinder_Melee_Mod_C
// Size: 0x190 (Inherited: 0x190)
struct UAmmoFinder_Melee_Mod_C : UItemFinder_Mod {
};

