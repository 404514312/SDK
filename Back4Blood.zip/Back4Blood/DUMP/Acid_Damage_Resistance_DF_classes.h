// BlueprintGeneratedClass Acid_Damage_Resistance_DF.Acid_Damage_Resistance_DF_C
// Size: 0x40 (Inherited: 0x40)
struct UAcid_Damage_Resistance_DF_C : UDamageFilter {
};

