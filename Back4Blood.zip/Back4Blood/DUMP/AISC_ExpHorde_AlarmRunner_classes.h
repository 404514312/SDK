// BlueprintGeneratedClass AISC_ExpHorde_AlarmRunner.AISC_ExpHorde_AlarmRunner_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_ExpHorde_AlarmRunner_C : UAISC_HordingBase_C {
};

