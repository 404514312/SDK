// BlueprintGeneratedClass AR04_4_BP.AR04_4_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR04_4_BP_C : AAR04_BP_C {
};

