// BlueprintGeneratedClass Affinity_Ammo_3_GE.Affinity_Ammo_3_GE_C
// Size: 0x320 (Inherited: 0x320)
struct UAffinity_Ammo_3_GE_C : UGameplayEffectInventoryComponent {
};

