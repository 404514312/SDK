// BlueprintGeneratedClass ADSBlur1_CameraModifier.ADSBlur1_CameraModifier_C
// Size: 0x630 (Inherited: 0x630)
struct UADSBlur1_CameraModifier_C : UCameraModifier_ADSScreenEffect {
};

