// BlueprintGeneratedClass ADSBlur1_ScreenEffect.ADSBlur1_ScreenEffect_C
// Size: 0x98 (Inherited: 0x98)
struct UADSBlur1_ScreenEffect_C : UScreenEffect {
};

