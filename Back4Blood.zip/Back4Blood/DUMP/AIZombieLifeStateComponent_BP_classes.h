// BlueprintGeneratedClass AIZombieLifeStateComponent_BP.AIZombieLifeStateComponent_BP_C
// Size: 0x210 (Inherited: 0x210)
struct UAIZombieLifeStateComponent_BP_C : ULifeStateComponent {
};

