// BlueprintGeneratedClass AISC_Wander_ChaserBunny_Alerted.AISC_Wander_ChaserBunny_Alerted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_ChaserBunny_Alerted_C : UAISC_WanderBase_C {
};

