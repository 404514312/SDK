// BlueprintGeneratedClass Ammo_Medium_Damage_Increase_Team_Mod.Ammo_Medium_Damage_Increase_Team_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAmmo_Medium_Damage_Increase_Team_Mod_C : UApplyGameplayEffectMod {
};

