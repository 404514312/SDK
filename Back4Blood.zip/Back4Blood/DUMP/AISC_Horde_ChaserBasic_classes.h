// BlueprintGeneratedClass AISC_Horde_ChaserBasic.AISC_Horde_ChaserBasic_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_ChaserBasic_C : UAISC_HordingBase_C {
};

