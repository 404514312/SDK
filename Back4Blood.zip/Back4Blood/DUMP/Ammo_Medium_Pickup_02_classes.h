// BlueprintGeneratedClass Ammo_Medium_Pickup_02.Ammo_Medium_Pickup_02_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Medium_Pickup_02_C : AAmmo_Medium_Pickup_Single_BP_C {
};

