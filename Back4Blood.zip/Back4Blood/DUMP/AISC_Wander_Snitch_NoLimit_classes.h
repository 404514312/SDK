// BlueprintGeneratedClass AISC_Wander_Snitch_NoLimit.AISC_Wander_Snitch_NoLimit_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Snitch_NoLimit_C : UAISC_WanderBase_C {
};

