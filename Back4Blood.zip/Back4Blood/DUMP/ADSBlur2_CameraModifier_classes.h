// BlueprintGeneratedClass ADSBlur2_CameraModifier.ADSBlur2_CameraModifier_C
// Size: 0x630 (Inherited: 0x630)
struct UADSBlur2_CameraModifier_C : UCameraModifier_ADSScreenEffect {
};

