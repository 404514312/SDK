// BlueprintGeneratedClass Acid_ScreenEffect.Acid_ScreenEffect_C
// Size: 0x98 (Inherited: 0x98)
struct UAcid_ScreenEffect_C : UScreenEffect {
};

