// BlueprintGeneratedClass AR02_1_Pickup_BP.AR02_1_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAR02_1_Pickup_BP_C : AItemPickupBase_BP_C {
};

