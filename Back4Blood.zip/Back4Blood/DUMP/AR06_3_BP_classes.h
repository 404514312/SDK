// BlueprintGeneratedClass AR06_3_BP.AR06_3_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR06_3_BP_C : AAR06_BP_C {
};

