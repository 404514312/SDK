// BlueprintGeneratedClass AISC_Challenge_ChaserSwarm_Bunny.AISC_Challenge_ChaserSwarm_Bunny_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Challenge_ChaserSwarm_Bunny_C : UAISC_Horde_ChaserBasic_C {
};

