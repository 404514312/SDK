// BlueprintGeneratedClass Ammo_Heavy_Pickup_Large_BP.Ammo_Heavy_Pickup_Large_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Heavy_Pickup_Large_BP_C : AAmmo_Pickup_Base_BP_C {
};

