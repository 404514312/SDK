// BlueprintGeneratedClass Acid_Damage_Resistance_GE.Acid_Damage_Resistance_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAcid_Damage_Resistance_GE_C : UGameplayEffectDamageFilter {
};

