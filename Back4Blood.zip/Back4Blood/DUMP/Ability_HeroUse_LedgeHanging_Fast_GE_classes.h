// BlueprintGeneratedClass Ability_HeroUse_LedgeHanging_Fast_GE.Ability_HeroUse_LedgeHanging_Fast_GE_C
// Size: 0x280 (Inherited: 0x280)
struct UAbility_HeroUse_LedgeHanging_Fast_GE_C : UGameplayEffectHeroUseComponent {
};

