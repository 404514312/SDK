// BlueprintGeneratedClass AISC_Wander_TallboyBasic.AISC_Wander_TallboyBasic_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_TallboyBasic_C : UAISC_WanderBase_C {
};

