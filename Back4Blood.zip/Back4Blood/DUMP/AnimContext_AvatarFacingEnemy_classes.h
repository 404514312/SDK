// BlueprintGeneratedClass AnimContext_AvatarFacingEnemy.AnimContext_AvatarFacingEnemy_C
// Size: 0x70 (Inherited: 0x70)
struct UAnimContext_AvatarFacingEnemy_C : UAnimContext_Facing {
};

