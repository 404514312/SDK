// BlueprintGeneratedClass AISC_Wander_Common_Runner.AISC_Wander_Common_Runner_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Common_Runner_C : UAISC_WanderBase_C {
};

