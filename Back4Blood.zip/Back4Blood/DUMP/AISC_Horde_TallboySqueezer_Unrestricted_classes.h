// BlueprintGeneratedClass AISC_Horde_TallboySqueezer_Unrestricted.AISC_Horde_TallboySqueezer_Unrestricted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_TallboySqueezer_Unrestricted_C : UAISC_Horde_TallboyBasic_C {
};

