// BlueprintGeneratedClass Achievement_GrabBag_002_Unlock_BP.Achievement_GrabBag_002_Unlock_BP_C
// Size: 0x320 (Inherited: 0x308)
struct AAchievement_GrabBag_002_Unlock_BP_C : AGobiSwitchActor_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x308(0x08)
	struct UStaticMeshComponent* Common_Gib_Foot_L_SM; // 0x310(0x08)
	struct UStaticMeshComponent* Suitcase_LRG_Open_01_SM; // 0x318(0x08)

	void ReceiveBeginPlay(); // Function Achievement_GrabBag_002_Unlock_BP.Achievement_GrabBag_002_Unlock_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2552680
};

