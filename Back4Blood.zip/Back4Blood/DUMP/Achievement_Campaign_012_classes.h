// BlueprintGeneratedClass Achievement_Campaign_012.Achievement_Campaign_012_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAchievement_Campaign_012_C : UMissionsCompletedAchievement {
};

