// BlueprintGeneratedClass Ammo_Special_Crate_BP.Ammo_Special_Crate_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Special_Crate_BP_C : AAmmo_Pickup_Base_BP_C {
};

