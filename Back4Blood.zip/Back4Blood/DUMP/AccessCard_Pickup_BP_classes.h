// BlueprintGeneratedClass AccessCard_Pickup_BP.AccessCard_Pickup_BP_C
// Size: 0x550 (Inherited: 0x540)
struct AAccessCard_Pickup_BP_C : AItemPickupBase_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)
	struct UHighlightComponent* Highlight; // 0x548(0x08)

	void CompleteIndustrialCarBatterObj(); // Function AccessCard_Pickup_BP.AccessCard_Pickup_BP_C.CompleteIndustrialCarBatterObj // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2552680
};

