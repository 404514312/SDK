// BlueprintGeneratedClass Alarm_Door_Low_Mod.Alarm_Door_Low_Mod_C
// Size: 0x288 (Inherited: 0x288)
struct UAlarm_Door_Low_Mod_C : UPassageSpawnerMod {
};

