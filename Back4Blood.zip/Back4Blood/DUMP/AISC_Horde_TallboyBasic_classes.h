// BlueprintGeneratedClass AISC_Horde_TallboyBasic.AISC_Horde_TallboyBasic_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_TallboyBasic_C : UAISC_HordingBase_C {
};

