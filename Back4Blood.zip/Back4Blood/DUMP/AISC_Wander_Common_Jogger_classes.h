// BlueprintGeneratedClass AISC_Wander_Common_Jogger.AISC_Wander_Common_Jogger_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Common_Jogger_C : UAISC_WanderBase_C {
};

