// BlueprintGeneratedClass AISC_Horde_Armored_Sprint.AISC_Horde_Armored_Sprint_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_Armored_Sprint_C : UAISC_Horde_Armored_Walk_C {
};

