// BlueprintGeneratedClass AISC_Wander_CamoArmored_Walk.AISC_Wander_CamoArmored_Walk_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_CamoArmored_Walk_C : UAISC_WanderBase_C {
};

