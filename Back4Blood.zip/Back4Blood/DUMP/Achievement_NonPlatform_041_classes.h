// BlueprintGeneratedClass Achievement_NonPlatform_041.Achievement_NonPlatform_041_C
// Size: 0xc0 (Inherited: 0xc0)
struct UAchievement_NonPlatform_041_C : UAchievement {
};

