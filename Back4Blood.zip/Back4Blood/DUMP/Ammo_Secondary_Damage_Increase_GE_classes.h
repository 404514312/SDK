// BlueprintGeneratedClass Ammo_Secondary_Damage_Increase_GE.Ammo_Secondary_Damage_Increase_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAmmo_Secondary_Damage_Increase_GE_C : UGameplayEffectDamageFilter {
};

