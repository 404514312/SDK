// BlueprintGeneratedClass Alert_GA.Alert_GA_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UAlert_GA_C : UGameplayAction_PlayMontage {
};

