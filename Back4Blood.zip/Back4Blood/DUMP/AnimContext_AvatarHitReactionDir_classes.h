// BlueprintGeneratedClass AnimContext_AvatarHitReactionDir.AnimContext_AvatarHitReactionDir_C
// Size: 0x80 (Inherited: 0x80)
struct UAnimContext_AvatarHitReactionDir_C : UAnimContext_Angle {
};

