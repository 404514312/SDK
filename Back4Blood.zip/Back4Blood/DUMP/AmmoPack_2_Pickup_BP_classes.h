// BlueprintGeneratedClass AmmoPack_2_Pickup_BP.AmmoPack_2_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAmmoPack_2_Pickup_BP_C : AAmmoPack_1_Pickup_BP_C {
};

