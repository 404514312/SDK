// BlueprintGeneratedClass AnimContext_AvatarFacingChaserLeapShortcut.AnimContext_AvatarFacingChaserLeapShortcut_C
// Size: 0x70 (Inherited: 0x70)
struct UAnimContext_AvatarFacingChaserLeapShortcut_C : UAnimContext_Facing {
};

