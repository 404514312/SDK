// BlueprintGeneratedClass AISC_Challenge_ChaserSwarm_Chaser.AISC_Challenge_ChaserSwarm_Chaser_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Challenge_ChaserSwarm_Chaser_C : UAISC_Horde_ChaserBasic_C {
};

