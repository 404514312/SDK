// BlueprintGeneratedClass Ammo_Medium_Damage_Increase_Self_Mod.Ammo_Medium_Damage_Increase_Self_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAmmo_Medium_Damage_Increase_Self_Mod_C : UApplyGameplayEffectMod {
};

