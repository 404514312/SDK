// BlueprintGeneratedClass AISC_Wander_Common_Walker.AISC_Wander_Common_Walker_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Common_Walker_C : UAISC_WanderBase_C {
};

