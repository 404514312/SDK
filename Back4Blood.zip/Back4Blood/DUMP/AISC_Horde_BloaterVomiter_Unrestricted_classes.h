// BlueprintGeneratedClass AISC_Horde_BloaterVomiter_Unrestricted.AISC_Horde_BloaterVomiter_Unrestricted_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_BloaterVomiter_Unrestricted_C : UAISC_Horde_BloaterBasic_C {
};

