// BlueprintGeneratedClass Ammo_Light_Damage_Increase_DF.Ammo_Light_Damage_Increase_DF_C
// Size: 0x40 (Inherited: 0x40)
struct UAmmo_Light_Damage_Increase_DF_C : UDamageFilter {
};

