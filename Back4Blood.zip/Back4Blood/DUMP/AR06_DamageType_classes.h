// BlueprintGeneratedClass AR06_DamageType.AR06_DamageType_C
// Size: 0x60 (Inherited: 0x60)
struct UAR06_DamageType_C : UBullet_DamageType_C {
};

