// BlueprintGeneratedClass Achievement_NonPlatform_036.Achievement_NonPlatform_036_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAchievement_NonPlatform_036_C : UEvangelosNightmareCheevo_BP_C {
};

