// BlueprintGeneratedClass Affinity_Health_3_GE.Affinity_Health_3_GE_C
// Size: 0x318 (Inherited: 0x318)
struct UAffinity_Health_3_GE_C : UGameplayEffectHealthComponent {
};

