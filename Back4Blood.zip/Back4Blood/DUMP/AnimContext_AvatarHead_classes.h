// BlueprintGeneratedClass AnimContext_AvatarHead.AnimContext_AvatarHead_C
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimContext_AvatarHead_C : UAnimContext_AvatarSocket {
};

