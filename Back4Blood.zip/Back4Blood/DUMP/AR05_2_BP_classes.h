// BlueprintGeneratedClass AR05_2_BP.AR05_2_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR05_2_BP_C : AAR05_BP_C {
};

