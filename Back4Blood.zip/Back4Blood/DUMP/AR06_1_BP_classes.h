// BlueprintGeneratedClass AR06_1_BP.AR06_1_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR06_1_BP_C : AAR06_BP_C {
};

