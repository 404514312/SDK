// BlueprintGeneratedClass AISC_Horde_ArmoredCommon_Jog.AISC_Horde_ArmoredCommon_Jog_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Horde_ArmoredCommon_Jog_C : UAISC_HordingBase_C {
};

