// BlueprintGeneratedClass ActiveHealAbility_BP.ActiveHealAbility_BP_C
// Size: 0x4b0 (Inherited: 0x4a0)
struct AActiveHealAbility_BP_C : AItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UApplyEffectItemComponent* ApplyEffectItem; // 0x4a8(0x08)

	void BndEvt__ApplyEffectItem_K2Node_ComponentBoundEvent_0_OnItemAppliedSignature__DelegateSignature(struct UApplyEffectItemComponent* ApplyEffectItemComponent, struct AItem* OwningItem, struct AActor* TargetActor); // Function ActiveHealAbility_BP.ActiveHealAbility_BP_C.BndEvt__ApplyEffectItem_K2Node_ComponentBoundEvent_0_OnItemAppliedSignature__DelegateSignature // (BlueprintEvent) // @ game+0x2552680
};

