// BlueprintGeneratedClass Ammo_Special_Pickup_Inf_BP.Ammo_Special_Pickup_Inf_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAmmo_Special_Pickup_Inf_BP_C : AItemPickupBase_BP_C {
};

