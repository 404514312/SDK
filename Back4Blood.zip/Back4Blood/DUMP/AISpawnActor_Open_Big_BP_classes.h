// BlueprintGeneratedClass AISpawnActor_Open_Big_BP.AISpawnActor_Open_Big_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AAISpawnActor_Open_Big_BP_C : AAISpawnActor_Open_BP_C {
};

