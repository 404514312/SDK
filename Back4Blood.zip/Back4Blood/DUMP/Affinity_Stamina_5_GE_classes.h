// BlueprintGeneratedClass Affinity_Stamina_5_GE.Affinity_Stamina_5_GE_C
// Size: 0x258 (Inherited: 0x258)
struct UAffinity_Stamina_5_GE_C : UGameplayEffectPlayerStaminaComponent {
};

