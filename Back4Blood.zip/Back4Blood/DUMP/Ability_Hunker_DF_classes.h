// BlueprintGeneratedClass Ability_Hunker_DF.Ability_Hunker_DF_C
// Size: 0x40 (Inherited: 0x40)
struct UAbility_Hunker_DF_C : UDamageFilter {
};

