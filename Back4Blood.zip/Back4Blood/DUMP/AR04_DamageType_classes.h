// BlueprintGeneratedClass AR04_DamageType.AR04_DamageType_C
// Size: 0x60 (Inherited: 0x60)
struct UAR04_DamageType_C : UBullet_DamageType_C {
};

