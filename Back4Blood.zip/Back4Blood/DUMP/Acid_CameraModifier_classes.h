// BlueprintGeneratedClass Acid_CameraModifier.Acid_CameraModifier_C
// Size: 0x630 (Inherited: 0x630)
struct UAcid_CameraModifier_C : UCameraModifier_ScreenEffect {
};

