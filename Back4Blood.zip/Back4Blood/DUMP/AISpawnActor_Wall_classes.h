// BlueprintGeneratedClass AISpawnActor_Wall.AISpawnActor_Wall_C
// Size: 0x578 (Inherited: 0x570)
struct AAISpawnActor_Wall_C : AAISpawnActor_BP_C {
	struct UHalfSpaceComponent* HalfSpace; // 0x570(0x08)
};

