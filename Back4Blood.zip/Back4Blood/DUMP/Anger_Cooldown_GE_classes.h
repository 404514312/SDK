// BlueprintGeneratedClass Anger_Cooldown_GE.Anger_Cooldown_GE_C
// Size: 0x270 (Inherited: 0x270)
struct UAnger_Cooldown_GE_C : UGameplayEffectSetTags {
};

