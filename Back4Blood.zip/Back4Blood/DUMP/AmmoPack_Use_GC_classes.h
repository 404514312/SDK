// BlueprintGeneratedClass AmmoPack_Use_GC.AmmoPack_Use_GC_C
// Size: 0x38 (Inherited: 0x30)
struct UAmmoPack_Use_GC_C : UGameplayCue_Blueprintable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x30(0x08)

	void K2_TriggerCue(struct FGameplayTag CueTag, struct FGameplayCueContext CueContext); // Function AmmoPack_Use_GC.AmmoPack_Use_GC_C.K2_TriggerCue // (Event|Public|BlueprintEvent) // @ game+0x2552680
};

