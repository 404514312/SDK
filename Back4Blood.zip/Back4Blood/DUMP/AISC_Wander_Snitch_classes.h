// BlueprintGeneratedClass AISC_Wander_Snitch.AISC_Wander_Snitch_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Snitch_C : UAISC_WanderBase_C {
};

