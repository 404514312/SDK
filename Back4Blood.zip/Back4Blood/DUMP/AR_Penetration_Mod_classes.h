// BlueprintGeneratedClass AR_Penetration_Mod.AR_Penetration_Mod_C
// Size: 0x220 (Inherited: 0x220)
struct UAR_Penetration_Mod_C : UApplyOnItemSelectedMod {
};

