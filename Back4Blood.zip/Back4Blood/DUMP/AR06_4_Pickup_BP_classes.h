// BlueprintGeneratedClass AR06_4_Pickup_BP.AR06_4_Pickup_BP_C
// Size: 0x540 (Inherited: 0x540)
struct AAR06_4_Pickup_BP_C : AAR06_1_Pickup_BP_C {
};

