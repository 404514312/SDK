// BlueprintGeneratedClass AISpawnActor_ExpWander_Sleeper_Wall_BP.AISpawnActor_ExpWander_Sleeper_Wall_BP_C
// Size: 0x578 (Inherited: 0x578)
struct AAISpawnActor_ExpWander_Sleeper_Wall_BP_C : AAISpawnActor_Sleeper_Wall_BP_C {
};

