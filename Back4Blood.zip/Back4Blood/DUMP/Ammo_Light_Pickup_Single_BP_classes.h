// BlueprintGeneratedClass Ammo_Light_Pickup_Single_BP.Ammo_Light_Pickup_Single_BP_C
// Size: 0x548 (Inherited: 0x548)
struct AAmmo_Light_Pickup_Single_BP_C : AAmmo_Pickup_Base_BP_C {
};

