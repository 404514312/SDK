// WidgetBlueprintGeneratedClass AffinityStats_WBP.AffinityStats_WBP_C
// Size: 0x478 (Inherited: 0x460)
struct UAffinityStats_WBP_C : UAffinityStatsUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct UImage* Hover; // 0x468(0x08)
	struct UHorizontalBox* StatsPanel; // 0x470(0x08)

	void UpdateStatHoveredState(); // Function AffinityStats_WBP.AffinityStats_WBP_C.UpdateStatHoveredState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2552680
};

