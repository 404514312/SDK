// BlueprintGeneratedClass AISpawnActor_Ledge_BP.AISpawnActor_Ledge_BP_C
// Size: 0x580 (Inherited: 0x570)
struct AAISpawnActor_Ledge_BP_C : AAISpawnActor_BP_C {
	struct UAnimContextLocatorComponent* AnimContextLocator; // 0x570(0x08)
	struct UHalfSpaceComponent* HalfSpace; // 0x578(0x08)
};

