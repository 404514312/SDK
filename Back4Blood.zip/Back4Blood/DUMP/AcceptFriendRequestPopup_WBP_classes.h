// WidgetBlueprintGeneratedClass AcceptFriendRequestPopup_WBP.AcceptFriendRequestPopup_WBP_C
// Size: 0x4a8 (Inherited: 0x470)
struct UAcceptFriendRequestPopup_WBP_C : UPopupUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x470(0x08)
	struct UTextButton_WBP_C* AcceptButton; // 0x478(0x08)
	struct UPlatformCalloutButton_WBP_C* BackCallout; // 0x480(0x08)
	struct UTextButton_WBP_C* BlockButton; // 0x488(0x08)
	struct UVerticalBox* ButtonPanel; // 0x490(0x08)
	struct UTextButton_WBP_C* DeclineButton; // 0x498(0x08)
	struct UBaseTextBlock_C* TitleText; // 0x4a0(0x08)

	void SetTitleText(struct FText& InText); // Function AcceptFriendRequestPopup_WBP.AcceptFriendRequestPopup_WBP_C.SetTitleText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2552680
};

