// BlueprintGeneratedClass Ammo_Light_Damage_Increase_Self_Mod.Ammo_Light_Damage_Increase_Self_Mod_C
// Size: 0x128 (Inherited: 0x128)
struct UAmmo_Light_Damage_Increase_Self_Mod_C : UApplyGameplayEffectMod {
};

