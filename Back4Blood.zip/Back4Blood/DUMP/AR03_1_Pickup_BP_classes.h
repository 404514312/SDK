// BlueprintGeneratedClass AR03_1_Pickup_BP.AR03_1_Pickup_BP_C
// Size: 0x548 (Inherited: 0x540)
struct AAR03_1_Pickup_BP_C : AItemPickupBase_BP_C {
	struct UStaticMeshComponent* SightMesh; // 0x540(0x08)
};

