// BlueprintGeneratedClass AR04_2_BP.AR04_2_BP_C
// Size: 0x558 (Inherited: 0x558)
struct AAR04_2_BP_C : AAR04_BP_C {
};

