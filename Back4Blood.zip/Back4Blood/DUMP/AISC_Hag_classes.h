// BlueprintGeneratedClass AISC_Hag.AISC_Hag_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Hag_C : UAISC_HordingBase_C {
};

