// BlueprintGeneratedClass AnimContext_AvatarHitDir.AnimContext_AvatarHitDir_C
// Size: 0x80 (Inherited: 0x80)
struct UAnimContext_AvatarHitDir_C : UAnimContext_Angle {
};

