// BlueprintGeneratedClass AISC_Wander_Armored_Jog.AISC_Wander_Armored_Jog_C
// Size: 0x138 (Inherited: 0x138)
struct UAISC_Wander_Armored_Jog_C : UAISC_WanderBase_C {
};

