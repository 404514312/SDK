// BlueprintGeneratedClass ActiveHealAbility_GE.ActiveHealAbility_GE_C
// Size: 0x290 (Inherited: 0x290)
struct UActiveHealAbility_GE_C : UGameplayEffectHeal {
};

