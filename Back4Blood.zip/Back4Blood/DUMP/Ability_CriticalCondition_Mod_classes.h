// BlueprintGeneratedClass Ability_CriticalCondition_Mod.Ability_CriticalCondition_Mod_C
// Size: 0x230 (Inherited: 0x230)
struct UAbility_CriticalCondition_Mod_C : UApplyOnTagMod {
};

